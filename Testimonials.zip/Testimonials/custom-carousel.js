document.addEventListener('DOMContentLoaded', function () {
    const multipleItemCarousel = document.querySelector("#testimonialCarousel");
    const items = document.querySelectorAll('.carousel-item');
    const totalItems = items.length;
    const itemsPerView = 3;  
   
    if (totalItems <= itemsPerView) {
       
        document.querySelector('.carousel-control-prev').style.display = 'none';
        document.querySelector('.carousel-control-next').style.display = 'none';
    } else {
        
        if (window.matchMedia("(min-width:576px)").matches) {
            const carousel = new bootstrap.Carousel(multipleItemCarousel, {
                interval: false
            });

            
            document.querySelector(".carousel-inner").style.scrollBehavior = "smooth";

           
            var carouselWidth = document.querySelector(".carousel-inner").scrollWidth;
            var cardWidth = document.querySelector(".carousel-item").offsetWidth;

            var scrollPosition = 0;

         
            document.querySelector(".carousel-control-next").addEventListener("click", function () {
                if (scrollPosition < carouselWidth - cardWidth * itemsPerView) {  // Ensure we don't scroll past the end
                    scrollPosition += cardWidth;  // Move to the next card
                    document.querySelector(".carousel-inner").scrollLeft = scrollPosition;  // Scroll smoothly
                }
            });

           
            document.querySelector(".carousel-control-prev").addEventListener("click", function () {
                if (scrollPosition > 0) {  // Ensure we don't scroll past the start
                    scrollPosition -= cardWidth;  // Move to the previous card
                    document.querySelector(".carousel-inner").scrollLeft = scrollPosition;  // Scroll smoothly
                }
            });
        } else {
            multipleItemCarousel.classList.add("slide");
        }
    }
});
