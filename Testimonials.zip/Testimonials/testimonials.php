<?php

/**
 * Plugin Name: Testimonials Plugin
 * Plugin URI: https://github.com/MoidPardesi
 * Description: A plugin to create and display testimonials using a custom post type.
 * Version: 1.0
 * Author: Abdul Moid
 * Author URI: https://github.com/MoidPardesi
 */

function create_testimonial_post_type() {
    $labels = array(
        'name' => 'Testimonials',
        'singular_name' => 'Testimonial',
        'menu_name' => 'Testimonials',
        'add_new' => 'Add New Testimonial',
        'add_new_item' => 'Add New Testimonial',
        'edit_item' => 'Edit Testimonial',
        'new_item' => 'New Testimonial',
        'view_item' => 'View Testimonial',
        'search_items' => 'Search Testimonials',
        'not_found' => 'No testimonials found',
        'not_found_in_trash' => 'No testimonials found in trash'
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'testimonials'),
        'supports' => array('title', 'editor', 'thumbnail'),
    );

    register_post_type('testimonial', $args);
}
add_action('init', 'create_testimonial_post_type');

function display_testimonials_carousel() {
    $args = array(
        'post_type' => 'testimonial',
        'posts_per_page' => -1
    );

    $testimonials = new WP_Query($args);
    if ($testimonials->have_posts()) {
        $output = '<div class="container-fluid bg-body-tertiary py-3">
            <div id="testimonialCarousel" class="carousel">
            <div class="carousel-inner">';

        $first = true;
        while ($testimonials->have_posts()) {
            $testimonials->the_post();
            $image = get_the_post_thumbnail_url(get_the_ID(), 'thumbnail');
            $content = get_the_content();
            $author = get_the_title();

            $output .= '<div class="carousel-item ' . ($first ? 'active' : '') . '">
                <div class="card shadow-sm rounded-3">
                    <div class="quotes display-2 text-body-tertiary">
                        <i class="bi bi-quote"></i>
                    </div>
                    <div class="card-body">
                        <p class="card-text">"' . esc_html($content) . '"</p>
                        <div class="d-flex align-items-center pt-2">
                            <img src="' . esc_url($image) . '" alt="Testimonial Author">
                            <div>
                                <h5 class="card-title fw-bold">' . esc_html($author) . '</h5>
                                <span class="text-secondary">CEO, Example Company</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
            $first = false;
        }

        wp_reset_postdata();

        $output .= '</div>
            <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
            </div></div>';
        return $output;
    } else {
        return '<p>No testimonials found.</p>';
    }
}
add_shortcode('show_testimonials_carousel', 'display_testimonials_carousel');

function enqueue_testimonials_carousel_assets() {
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css');
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js', array('jquery'), null, true);
    wp_enqueue_style('testimonials-carousel-css', plugins_url('/style.css', __FILE__));
    wp_enqueue_script('testimonials-carousel-js', plugins_url('/custom-carousel.js', __FILE__), array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_testimonials_carousel_assets');
